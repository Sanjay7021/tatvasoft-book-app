
export const Role = {
    Admin:1,
    Seller: 2,
    Buyer: 3,
}