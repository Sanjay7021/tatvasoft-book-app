export const defaultFilter = {
    pageIndex: 1,
    pageSize: 10,
    keyword: "",
}

export const RecordsPerPage = [2,5,10,100]; 