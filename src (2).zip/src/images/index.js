export const logo = require("./tatvasoft.png").default;
export const loadIcon = require("./Cube-1s-200px.svg").default;